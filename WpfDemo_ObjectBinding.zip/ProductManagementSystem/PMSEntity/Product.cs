﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSEntity
{
    /// <summary>
    /// Author: Capgemini
    /// Date Of Creation: 10-Nov-2017
    /// Description: Product class with Properties defined 
    /// </summary>
   // [Serializable]
   // [Category("COD Available")]
   // [Category("Special Discount")]
    public class Product
    {
        public int ProductId { get; set; } // Gets and Sets the ProductId
        public string ProductName { get; set; }
        public string Category { get; set; }
    //    [NonSerialized]
        public int Price { get; set; }
        public DateTime ExpiryDate { get; set; }

    }
}
