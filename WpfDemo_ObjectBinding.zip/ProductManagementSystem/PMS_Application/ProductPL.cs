﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMSEntity;
using PMSException;
using PMS_BLL;
using System.IO;
namespace PMS_Application
{ 
    /// <summary>
    ///  Author: Capgemini
    /// Date Of Creation: 10-Nov-2017
    /// Description: UI for PMS
    /// </summary>
    class ProductPL
    {
     static ProductValidation bllProduct = new ProductValidation();
        //Method to print menu to the user for user's choice
        public static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("*****Product Management System*************");
            Console.WriteLine("1.  To Add Product Details  - Press 1,");
            Console.WriteLine("2.  To Display All Products - Press 2,");
            Console.WriteLine("3.  To Search a Product     - Press 3,");
            Console.WriteLine("4.  To Update a Product     - Press 4,");
            Console.WriteLine("5.  To Delete a Product     - Press 5,");
            Console.WriteLine("6.  To Serialize Data       - Press 6,");
            Console.WriteLine("7.  To Deserialize Data     - Press 7,");
            Console.WriteLine("8.  To Exit the Application - Press 8,");
            Console.WriteLine("*********************************************");
        }

        public static void AddProductPL()
        {
            try
            {
            Product myProduct = new Product();
            Console.WriteLine("Enter Product Id");
            myProduct.ProductId = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter Product Name");
            myProduct.ProductName = Console.ReadLine();
            Console.WriteLine("Enter Category (Should be Food or Beverages)");
            myProduct.Category = Console.ReadLine();
            Console.WriteLine("Enter Product Price");
            myProduct.Price = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter Expiry Date");
            myProduct.ExpiryDate = DateTime.Parse(Console.ReadLine());
           
            if (bllProduct.AddProductBLL(myProduct))
            {
                Console.WriteLine("Product Details added successfully");
            }                 
            }

            catch (ProductException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Format Exception occurred "+ ex.Message);
            }
            catch(Exception ex)
            { Console.WriteLine(ex.Message); }
        }

        public static void DisplayProductPL()
        {
            List<Product> pList = new List<Product>();
             ProductValidation bllProduct = new ProductValidation();
            try 
            {
                pList = bllProduct.DisplayProductBLL();

                Console.WriteLine("*************************All Product Detail**************************");
                Console.WriteLine("Product ID      Product Name    Category       Price      ExpiryDate");
                Console.WriteLine("---------------------------------------------------------------------");
                   
                foreach (Product product in pList)
                {

                   Console.WriteLine(" {0} \t\t {1} \t\t {2} \t\t {3} \t {4}", product.ProductId, product.ProductName, product.Category,product.Price,product.ExpiryDate.ToShortDateString() );        
                }
                
                //Getting the category information
                CategoryAttribute[] catAttr =(CategoryAttribute[]) Attribute.GetCustomAttributes(typeof(Product),typeof(CategoryAttribute));
                foreach (CategoryAttribute attr in catAttr)
                {
                    Console.WriteLine("Product comes under the category type:" + attr.CategoryType);
                
                }

            }
            catch (ProductException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            { Console.WriteLine(ex.Message); }
        
        }
        public static void DeleteProductPL() 
        {

            int ProductID;
            bool ProductDeleted;

            try
            {
                //User Inputs
                Console.Write("Enter the Product ID to be deleted : ");
                ProductID = Convert.ToInt32(Console.ReadLine());
                //Calling the ProductBL class to use it's function AND using NAMED ARGUMENTS
                ProductDeleted = bllProduct.DeleteProduct(ProductID);

                if (ProductDeleted == true)
                    Console.WriteLine("Product Deleted Successfully!");
                else
                    throw new ProductException("Product not deleted!");
            }
            //Catching User defined exception
            catch (ProductException p)
            {
                Console.WriteLine(p.Message);
            }
            //Catching System exception
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void SearchProductPL()
        {
            int ProductID;
            Product searchedProduct;

            try
            {
                Console.Write("Enter Product ID for search : ");
                ProductID = Convert.ToInt32(Console.ReadLine());

                //Checking if all validations by calling the ProductBiz class to use it's function AND using are true AND using NAMED ARGUMENTS
                searchedProduct =bllProduct.SearchProductBL(ProductID: ProductID);

                if (searchedProduct != null)
                {
                    Console.WriteLine("Product ID      : " + searchedProduct.ProductId);
                    Console.WriteLine("Product Name    : " + searchedProduct.ProductName);
                    Console.WriteLine("Product Category: " + searchedProduct.Category);
                    Console.WriteLine("Price           : " + searchedProduct.Price);
                    Console.WriteLine("Expiry Date     : " + searchedProduct.ExpiryDate);

                }
                else
                {
                    throw new ProductException("Product not found!");
                }
            }
            //Catching User defined exception
            catch (ProductException p)
            {
                Console.WriteLine(p.Message);
            }
            //Catching System exception
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        
        }

        public static void UpdateProductPL()
        {
            Product ProductToBeUpdated = new Product();
            bool ProductUpdated;

            try
            {

                //User inputs
                Console.Write("Enter Product ID for which you would like to update the record : ");
                ProductToBeUpdated.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Product Name to be updated : ");
                ProductToBeUpdated.ProductName = Console.ReadLine();
                Console.Write("Enter Product Category to be updated : ");
                ProductToBeUpdated.Category = Console.ReadLine();
                Console.Write("Enter Product Price to be updated : ");
                ProductToBeUpdated.Price = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Product Expiry Date to be updated : ");
                ProductToBeUpdated.ExpiryDate = DateTime.Parse(Console.ReadLine());

                //Checking if all validations by calling the ProductBL class to use it's function 
                ProductUpdated = bllProduct.UpdateProduct(ProductToBeUpdated);

                //Checking if validations are true or not
                if (ProductUpdated == true)
                    Console.WriteLine("Product Updated Successfully!");
                else
                    throw new ProductException("Product not updated!");
            }
            //Catching User defined exception
            catch (ProductException p)
            {
                Console.WriteLine(p.Message);
            }
            //Catching System exception
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void SerializeProduct()
        {
            try 
            {
                bllProduct.SerializeProducBL();
                Console.WriteLine("Data Stored to collection Successfully");
            }
            catch (ProductException e) { Console.WriteLine(e.Message); }
            catch (IOException e) { Console.WriteLine(e.Message); }
 
        }
        public static void DeserializeProduct()
        {
            try
            {
                List<Product> productList = new List<Product>();
               productList= bllProduct.DisplayFromFile();
               Console.WriteLine("Products From File :");
               foreach (Product prod in productList)
               {
                   Console.WriteLine("Product ID : {0}\nProduct Name : {1}\nCategory :{2}\n Price:{3}\n ExpiryDate :{4}", prod.ProductId, prod.ProductName, prod.Category, prod.Price, prod.ExpiryDate);
               
               }
               
            }
            catch (ProductException e) { Console.WriteLine(e.Message); }
            catch (IOException e) { Console.WriteLine(e.Message); }
        }
        
        static void Main(string[] args)
        {
            int userchoice;
            bool chkchoice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice from the Menu");
                chkchoice = Int32.TryParse(Console.ReadLine(), out userchoice);
                if (!chkchoice)
                    Console.WriteLine("Enter a Valid Choice from the Menu");
                else
                    switch (userchoice)
                    {
                        case 1: AddProductPL();
                            break;
                        case 2: DisplayProductPL();
                            break;
                        case 3: SearchProductPL();
                            break;
                        case 4: UpdateProductPL();
                            break;
                        case 5: DeleteProductPL();
                            break;
                        case 6: SerializeProduct();
                            break;
                        case 7: DeserializeProduct();
                            break;
                        case 8: break;
                        default: Console.WriteLine("Invalid Choice");
                            break;

                    }
            } while (userchoice != 8);

        }
    }
}
