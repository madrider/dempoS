﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleEmployee
{
    class EmployeeDetails
    {
        public Employee GetEmployee()
        {
            Employee newEmp = new Employee { EmployeeId = 1010, EmployeeName = "Sangeetha", Department = "Training" };
            return newEmp;
        
        }
    }
}
